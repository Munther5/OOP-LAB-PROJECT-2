package FuelCar2;
import java.util.Locale;

public class Fuel2 {
    // Instance variables
    private String carType;
    private Car1[] fillUps;
    private FuelConsumptionStrategy calc; // Strategy pattern implementation
    
    public double calculate(double distance, double fuelUsed) {
        return calc.calculate(distance, fuelUsed);
    }
    // Default Constructor
    public Fuel2() {}

    // Parameterized Constructor
    public Fuel2(String carType, Car1[] fillUps) {
        this.carType = carType;
        this.fillUps = fillUps;
    }

    // Setter Methods
    public void setCarType(String carType) { this.carType = carType; }
    public void setFillUps(Car1[] fillUps) { this.fillUps = fillUps; }
    public void setReadingMethod(FuelConsumptionStrategy strategy) {this.calc = strategy;}

    // Method to print multiple fill-ups for a single car1
    public void printReport() {
        System.out.println("Gas Mileage Calculations");
        System.out.printf(Locale.US, "%-22s %-12s %-12s %-10s %-10s %-10s %-10s %-10s %-10s\n", 
                          "Type of Car", "Start Miles", "End Miles", "Distance", "Liters", "Price", "Cost", "KM/L", "L/100KM");
        System.out.println("===============================================================================================================");
        for (Car1 fillUp : fillUps) {
            System.out.printf(Locale.US, "%-22s %-12d %-12d %-10d %-10.2f %-10.2f %-10.2f %-10.2f %-10.4f\n",
                carType,
                fillUp.getStartKms(),
                fillUp.getEndKms(),
                fillUp.calcDistance(),
                fillUp.getLitersUsed(),
                fillUp.getPricePerLiter(),
                fillUp.totalCost(),
                fillUp.calcKmPL(),
                fillUp.calcLiterP100Km()
            );
        }
    }

    public static void main(String[] args) {
        //Using the default constructor and creating car1 object
        Car1 fillUp1 = new Car1();
        fillUp1.setStartKms(40189);
        fillUp1.setEndKms(41073);
        fillUp1.setLitersUsed(40);
        fillUp1.setPricePerLiter(2.18);

        Car1 fillUp2 = new Car1();
        fillUp2.setStartKms(41073);
        fillUp2.setEndKms(41625);
        fillUp2.setLitersUsed(25);
        fillUp2.setPricePerLiter(2.18);

        Car1 fillUp3 = new Car1();
        fillUp3.setStartKms(41625);
        fillUp3.setEndKms(42509);
        fillUp3.setLitersUsed(40);
        fillUp3.setPricePerLiter(2.18);

        Car1 fillUp4 = new Car1();
        fillUp4.setStartKms(42509);
        fillUp4.setEndKms(43172);
        fillUp4.setLitersUsed(30);
        fillUp4.setPricePerLiter(2.18);

        Car1 fillUp5 = new Car1();
        fillUp5.setStartKms(43172);
        fillUp5.setEndKms(43614);
        fillUp5.setLitersUsed(20);
        fillUp5.setPricePerLiter(2.18);

        // Adding all fill-ups to an array
        Car1[] fillUps = { fillUp1, fillUp2, fillUp3, fillUp4, fillUp5 };

        Fuel2 car1 = new Fuel2();
        car1.setCarType("2023 Mitsubishi Attrage");
        car1.setFillUps(fillUps);
    
        // Setting the reading method to MPG strategy
        car1.setReadingMethod(new MilesPerGallonStrategy());
        System.out.println("Fuel consumption (MPG): " + car1.calculate(549.29, 10.57));

        // Setting the reading method to GPM strategy
        car1.setReadingMethod(new GallonsPerMileStrategy());
        System.out.println("Fuel consumption (GPM): " + car1.calculate(549.29, 10.57));
       
        // Setting the reading method to KM/L strategy
        car1.setReadingMethod(new KmPerLiterStrategy());
        System.out.println("Fuel consumption (KM/L): " + car1.calculate(884, 40));
        
        // Setting the reading method to L/100KM strategy
        car1.setReadingMethod(new LitersPer100KmStrategy());
        System.out.println("Fuel consumption (L/100KM): " + car1.calculate(884, 40));
        
     

        car1.printReport();
    }
}

class Car1 {
    private int startKms;
    private int endKms;
    private double litersUsed;
    private double pricePerLiter;

    // Default Constructor
    public Car1() {}

    // Parameterized Constructor
    public Car1(int startKms, int endKms, double litersUsed, double pricePerLiter) {
        this.startKms = startKms;
        this.endKms = endKms;
        this.litersUsed = litersUsed;
        this.pricePerLiter = pricePerLiter;
    }

    // Setter Methods
    public void setStartKms(int startKms) { this.startKms = startKms; }
    public void setEndKms(int endKms) { this.endKms = endKms; }
    public void setLitersUsed(double litersUsed) { this.litersUsed = litersUsed; }
    public void setPricePerLiter(double pricePerLiter) { this.pricePerLiter = pricePerLiter; }

    public int getStartKms() { return startKms; }
    public int getEndKms() { return endKms; }
    public double getLitersUsed() { return litersUsed; }
    public double getPricePerLiter() { return pricePerLiter; }

    public int calcDistance() {
        return endKms - startKms;
    }

    public double calcKmPL() {
        return calcDistance() / litersUsed;
    }

    public double calcLiterP100Km() {
        return (litersUsed / calcDistance()) * 100;
    }

    public double totalCost() {
        return litersUsed * pricePerLiter;
    }
}