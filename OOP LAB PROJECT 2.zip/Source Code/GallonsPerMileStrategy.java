package FuelCar2;

//Strategy for calculating Gallons Per Mile (GPM)
public class GallonsPerMileStrategy implements FuelConsumptionStrategy {
 @Override
 public double calculate(double distance, double fuelUsed) {
     double miles = distance * 0.6214; // Convert km to miles
     double gallons = fuelUsed / 3.7854; // Convert liters to gallons
     return gallons / miles; // GPM calculation
 }
}