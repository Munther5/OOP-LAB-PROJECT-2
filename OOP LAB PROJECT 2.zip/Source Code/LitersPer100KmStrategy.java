package FuelCar2;

//Strategy for calculating Liters Per 100KM (L/100KM)
public class LitersPer100KmStrategy implements FuelConsumptionStrategy {
 @Override
 public double calculate(double distance, double fuelUsed) {
     return (fuelUsed / distance) * 100; // L/100KM calculation
 }
}
