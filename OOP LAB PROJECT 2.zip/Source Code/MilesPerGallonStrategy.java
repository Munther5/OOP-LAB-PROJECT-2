package FuelCar2;

public class MilesPerGallonStrategy implements FuelConsumptionStrategy {
    @Override
    public double calculate(double distance, double fuelUsed) {
        double miles = distance * 0.6214;
        double gallons = fuelUsed / 3.7854;
        return miles / gallons;
    }
}