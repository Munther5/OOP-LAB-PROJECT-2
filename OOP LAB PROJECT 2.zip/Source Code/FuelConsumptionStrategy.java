package FuelCar2;

// Interface to define a fuel consumption strategy
public interface FuelConsumptionStrategy {
    double calculate(double distance, double fuelUsed);
}