package FuelCar2;

//Strategy for calculating Kilometers Per Liter (KM/L)
public class KmPerLiterStrategy implements FuelConsumptionStrategy {
 @Override
 public double calculate(double distance, double fuelUsed) {
     return distance / fuelUsed; // KM/L calculation
 }
}